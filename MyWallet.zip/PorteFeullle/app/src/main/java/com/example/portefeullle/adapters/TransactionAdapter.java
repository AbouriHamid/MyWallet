package com.example.portefeullle.adapters;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.example.portefeullle.R;
import com.example.portefeullle.data.Transaction;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class TransactionAdapter extends RecyclerView.Adapter<TransactionAdapter.TransactionViewHolder> {
    private List<Transaction> transactions = new ArrayList<>();
    private SimpleDateFormat dateFormat = new SimpleDateFormat("MMM dd, yyyy", Locale.getDefault());

    @NonNull
    @Override
    public TransactionViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_transaction, parent, false);
        return new TransactionViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull TransactionViewHolder holder, int position) {
        Transaction transaction = transactions.get(position);
        holder.transactionTitle.setText(transaction.getDescription());
        holder.transactionDate.setText(dateFormat.format(new Date(transaction.getDate())));
        
        String amountText = String.format("$%.2f", transaction.getAmount());
        if (transaction.isExpense()) {
            amountText = "-" + amountText;
            holder.transactionAmount.setTextColor(0xFFE53935); // Red color
        } else {
            amountText = "+" + amountText;
            holder.transactionAmount.setTextColor(0xFF43A047); // Green color
        }
        holder.transactionAmount.setText(amountText);
    }

    @Override
    public int getItemCount() {
        return transactions.size();
    }

    public void setTransactions(List<Transaction> transactions) {
        this.transactions = transactions;
        notifyDataSetChanged();
    }

    static class TransactionViewHolder extends RecyclerView.ViewHolder {
        private TextView transactionTitle;
        private TextView transactionDate;
        private TextView transactionAmount;

        public TransactionViewHolder(View itemView) {
            super(itemView);
            transactionTitle = itemView.findViewById(R.id.transaction_title);
            transactionDate = itemView.findViewById(R.id.transaction_date);
            transactionAmount = itemView.findViewById(R.id.transaction_amount);
        }
    }
} 