package com.example.portefeullle;

import android.app.AlertDialog;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.RadioGroup;
import android.widget.Spinner;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.example.portefeullle.adapters.TransactionAdapter;
import com.example.portefeullle.data.AppDatabase;
import com.example.portefeullle.data.Transaction;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class TransactionsFragment extends Fragment {
    private RecyclerView recyclerView;
    private FloatingActionButton fabAddTransaction;
    private TransactionAdapter adapter;
    private AppDatabase database;
    private ExecutorService executorService;
    private List<String> categories = new ArrayList<>();
    private ArrayAdapter<String> categoryAdapter;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_transactions, container, false);
        
        database = AppDatabase.getInstance(requireContext());
        executorService = Executors.newSingleThreadExecutor();
        
        recyclerView = view.findViewById(R.id.transactions_recycler_view);
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
        
        adapter = new TransactionAdapter();
        recyclerView.setAdapter(adapter);
        
        fabAddTransaction = view.findViewById(R.id.fab_add_transaction);
        fabAddTransaction.setOnClickListener(v -> showAddTransactionDialog());
        
        // Create category adapter
        categoryAdapter = new ArrayAdapter<>(
            getContext(),
            android.R.layout.simple_spinner_dropdown_item,
            categories
        );

        // Observe categories
        database.categoryDao().getAllCategoryNames().observe(getViewLifecycleOwner(), categoryNames -> {
            categories.clear();
            categories.addAll(categoryNames);
            categoryAdapter.notifyDataSetChanged();
        });
        
        // Observe transactions
        database.transactionDao().getAllTransactions().observe(getViewLifecycleOwner(), transactions -> {
            adapter.setTransactions(transactions);
        });
        
        return view;
    }

    private void showAddTransactionDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(getContext());
        LayoutInflater inflater = requireActivity().getLayoutInflater();
        View dialogView = inflater.inflate(R.layout.dialog_add_transaction, null);
        
        EditText amountEdit = dialogView.findViewById(R.id.edit_amount);
        EditText descriptionEdit = dialogView.findViewById(R.id.edit_description);
        Spinner categorySpinner = dialogView.findViewById(R.id.spinner_category);
        RadioGroup typeGroup = dialogView.findViewById(R.id.transaction_type);

        // Set up category spinner
        categorySpinner.setAdapter(categoryAdapter);

        // Show message if no categories exist
        if (categories.isEmpty()) {
            new AlertDialog.Builder(getContext())
                .setTitle("No Categories")
                .setMessage("Please add some categories first.")
                .setPositiveButton("OK", (dialog, which) -> {
                    // Navigate to Categories fragment
                    ((MainActivity) requireActivity()).navigateToCategories();
                })
                .show();
            return;
        }

        builder.setView(dialogView)
               .setTitle("Add Transaction")
               .setPositiveButton("Add", (dialog, which) -> {
                   String amountStr = amountEdit.getText().toString();
                   String description = descriptionEdit.getText().toString();
                   String category = categorySpinner.getSelectedItem().toString();
                   boolean isExpense = typeGroup.getCheckedRadioButtonId() == R.id.radio_expense;

                   if (!amountStr.isEmpty() && !description.isEmpty()) {
                       double amount = Double.parseDouble(amountStr);
                       Transaction transaction = new Transaction(amount, description, category, isExpense);
                       saveTransaction(transaction);
                   }
               })
               .setNegativeButton("Cancel", (dialog, which) -> dialog.cancel());

        builder.create().show();
    }

    private void saveTransaction(Transaction transaction) {
        executorService.execute(() -> {
            database.transactionDao().insert(transaction);
        });
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        executorService.shutdown();
    }
} 