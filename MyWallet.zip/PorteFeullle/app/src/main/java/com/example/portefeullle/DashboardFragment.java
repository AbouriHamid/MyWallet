package com.example.portefeullle;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.example.portefeullle.adapters.MonthlyBreakdownAdapter;
import com.example.portefeullle.adapters.TransactionAdapter;
import com.example.portefeullle.data.AppDatabase;
import com.example.portefeullle.data.Transaction;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class DashboardFragment extends Fragment {
    private TextView balanceAmount;
    private TextView incomeAmount;
    private TextView expensesAmount;
    private RecyclerView recentTransactionsRecycler;
    private RecyclerView monthlyBreakdownRecycler;
    private AppDatabase database;
    private TransactionAdapter recentTransactionsAdapter;
    private MonthlyBreakdownAdapter monthlyBreakdownAdapter;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_dashboard, container, false);

        // Initialize views
        balanceAmount = view.findViewById(R.id.balance_amount);
        incomeAmount = view.findViewById(R.id.income_amount);
        expensesAmount = view.findViewById(R.id.expenses_amount);
        recentTransactionsRecycler = view.findViewById(R.id.recent_transactions_recycler);
        monthlyBreakdownRecycler = view.findViewById(R.id.monthly_breakdown_recycler);

        // Setup RecyclerViews
        recentTransactionsRecycler.setLayoutManager(new LinearLayoutManager(getContext()));
        monthlyBreakdownRecycler.setLayoutManager(new LinearLayoutManager(getContext()));

        recentTransactionsAdapter = new TransactionAdapter();
        monthlyBreakdownAdapter = new MonthlyBreakdownAdapter();

        recentTransactionsRecycler.setAdapter(recentTransactionsAdapter);
        monthlyBreakdownRecycler.setAdapter(monthlyBreakdownAdapter);

        // Get database instance
        database = AppDatabase.getInstance(requireContext());

        // Observe transactions
        database.transactionDao().getAllTransactions().observe(getViewLifecycleOwner(), transactions -> {
            updateDashboard(transactions);
            updateRecentTransactions(transactions);
            updateMonthlyBreakdown(transactions);
        });

        return view;
    }

    private void updateDashboard(List<Transaction> transactions) {
        double totalIncome = 0;
        double totalExpenses = 0;

        for (Transaction transaction : transactions) {
            if (transaction.isExpense()) {
                totalExpenses += transaction.getAmount();
            } else {
                totalIncome += transaction.getAmount();
            }
        }

        double balance = totalIncome - totalExpenses;

        balanceAmount.setText(String.format("$%.2f", balance));
        incomeAmount.setText(String.format("$%.2f", totalIncome));
        expensesAmount.setText(String.format("$%.2f", totalExpenses));

        if (balance < 0) {
            balanceAmount.setTextColor(0xFFE53935);
        } else {
            balanceAmount.setTextColor(0xFF43A047);
        }
    }

    private void updateRecentTransactions(List<Transaction> transactions) {
        // Show only the 5 most recent transactions
        int endIndex = Math.min(5, transactions.size());
        List<Transaction> recentTransactions = transactions.subList(0, endIndex);
        recentTransactionsAdapter.setTransactions(recentTransactions);
    }

    private void updateMonthlyBreakdown(List<Transaction> transactions) {
        Map<String, Double> categoryTotals = new HashMap<>();
        Calendar calendar = Calendar.getInstance();
        int currentMonth = calendar.get(Calendar.MONTH);
        int currentYear = calendar.get(Calendar.YEAR);

        // Calculate totals for current month
        for (Transaction transaction : transactions) {
            Calendar transactionDate = Calendar.getInstance();
            transactionDate.setTimeInMillis(transaction.getDate());
            
            if (transactionDate.get(Calendar.MONTH) == currentMonth && 
                transactionDate.get(Calendar.YEAR) == currentYear && 
                transaction.isExpense()) {
                
                String category = transaction.getCategory();
                double currentTotal = categoryTotals.getOrDefault(category, 0.0);
                categoryTotals.put(category, currentTotal + transaction.getAmount());
            }
        }

        monthlyBreakdownAdapter.setCategoryTotals(categoryTotals);
    }

    @Override
    public void onResume() {
        super.onResume();
        // Refresh data when fragment becomes visible
        database.transactionDao().getAllTransactions().observe(getViewLifecycleOwner(), transactions -> {
            updateDashboard(transactions);
            updateRecentTransactions(transactions);
            updateMonthlyBreakdown(transactions);
        });
    }
} 