package com.example.portefeullle.adapters;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.example.portefeullle.R;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class MonthlyBreakdownAdapter extends RecyclerView.Adapter<MonthlyBreakdownAdapter.BreakdownViewHolder> {
    private List<CategoryTotal> categoryTotals = new ArrayList<>();

    public void setCategoryTotals(Map<String, Double> totals) {
        categoryTotals.clear();
        for (Map.Entry<String, Double> entry : totals.entrySet()) {
            categoryTotals.add(new CategoryTotal(entry.getKey(), entry.getValue()));
        }
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public BreakdownViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_category_total, parent, false);
        return new BreakdownViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull BreakdownViewHolder holder, int position) {
        CategoryTotal categoryTotal = categoryTotals.get(position);
        holder.categoryName.setText(categoryTotal.category);
        holder.categoryAmount.setText(String.format("$%.2f", categoryTotal.total));
    }

    @Override
    public int getItemCount() {
        return categoryTotals.size();
    }

    static class BreakdownViewHolder extends RecyclerView.ViewHolder {
        TextView categoryName;
        TextView categoryAmount;

        BreakdownViewHolder(View itemView) {
            super(itemView);
            categoryName = itemView.findViewById(R.id.category_name);
            categoryAmount = itemView.findViewById(R.id.category_amount);
        }
    }

    private static class CategoryTotal {
        String category;
        double total;

        CategoryTotal(String category, double total) {
            this.category = category;
            this.total = total;
        }
    }
} 