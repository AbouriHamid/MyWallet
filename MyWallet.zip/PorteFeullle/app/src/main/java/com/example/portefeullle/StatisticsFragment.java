package com.example.portefeullle;

import android.graphics.Color;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.example.portefeullle.adapters.CategoryBreakdownAdapter;
import com.example.portefeullle.data.AppDatabase;
import com.example.portefeullle.data.Transaction;
import com.github.mikephil.charting.charts.BarChart;
import com.github.mikephil.charting.charts.PieChart;
import com.github.mikephil.charting.components.XAxis;
import com.github.mikephil.charting.data.BarData;
import com.github.mikephil.charting.data.BarDataSet;
import com.github.mikephil.charting.data.BarEntry;
import com.github.mikephil.charting.data.PieData;
import com.github.mikephil.charting.data.PieDataSet;
import com.github.mikephil.charting.data.PieEntry;
import com.github.mikephil.charting.formatter.IndexAxisValueFormatter;
import com.github.mikephil.charting.utils.ColorTemplate;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Environment;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.itextpdf.kernel.pdf.PdfDocument;
import com.itextpdf.kernel.pdf.PdfWriter;
import com.itextpdf.layout.Document;
import com.itextpdf.layout.element.Paragraph;
import com.itextpdf.layout.element.Table;
import java.io.File;
import java.io.FileOutputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import android.app.AlertDialog;
import static android.content.pm.PackageManager.PERMISSION_GRANTED;
import android.util.Log;
import android.content.Intent;
import android.net.Uri;
import android.provider.Settings;
import android.os.Build;
import androidx.annotation.NonNull;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.provider.MediaStore;
import java.io.OutputStream;
import android.app.Activity;
import static android.app.Activity.RESULT_OK;

public class StatisticsFragment extends Fragment {
    private static final int PERMISSION_REQUEST_CODE = 123;
    private static final String TAG = "StatisticsFragment";
    private PieChart pieChart;
    private BarChart barChart;
    private TextView monthlySpending;
    private TextView trendAnalysis;
    private RecyclerView categoryBreakdownList;
    private AppDatabase database;
    private final SimpleDateFormat monthFormat = new SimpleDateFormat("MMM yyyy", Locale.getDefault());
    private FloatingActionButton fabExportPdf;
    private List<Transaction> currentTransactions = new ArrayList<>();
    private static final int CREATE_FILE_REQUEST_CODE = 1;
    private TextView netBalance;
    private TextView monthlyIncome;
    private TextView incomeChange;
    private TextView spendingChange;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        Log.d(TAG, "onCreateView: Starting initialization");
        View view = inflater.inflate(R.layout.fragment_statistics, container, false);

        try {
            Log.d(TAG, "onCreateView: Initializing views");
            // Initialize views
            pieChart = view.findViewById(R.id.pie_chart);
            barChart = view.findViewById(R.id.bar_chart);
            monthlySpending = view.findViewById(R.id.monthly_spending);
            trendAnalysis = view.findViewById(R.id.trend_analysis);
            categoryBreakdownList = view.findViewById(R.id.category_breakdown_list);
            fabExportPdf = view.findViewById(R.id.fab_export_pdf);
            netBalance = view.findViewById(R.id.net_balance);
            monthlyIncome = view.findViewById(R.id.monthly_income);
            incomeChange = view.findViewById(R.id.income_change);
            spendingChange = view.findViewById(R.id.spending_change);

            Log.d(TAG, "onCreateView: Setting up database");
            database = AppDatabase.getInstance(requireContext());

            Log.d(TAG, "onCreateView: Setting up charts");
            setupPieChart();
            setupBarChart();
            setupCategoryBreakdownList();

            Log.d(TAG, "onCreateView: Setting up PDF export");
            if (fabExportPdf != null) {
                fabExportPdf.setOnClickListener(v -> checkPermissionAndExportPdf());
            }

            Log.d(TAG, "onCreateView: Setting up transaction observer");
            database.transactionDao().getAllTransactions().observe(getViewLifecycleOwner(), transactions -> {
                Log.d(TAG, "Transaction update received: " + (transactions != null ? transactions.size() : 0) + " items");
                try {
                    if (transactions != null) {
                        currentTransactions = new ArrayList<>(transactions);
                        updateStatistics(transactions);
                    }
                } catch (Exception e) {
                    Log.e(TAG, "Error updating transactions", e);
                }
            });

        } catch (Exception e) {
            Log.e(TAG, "Error in onCreateView", e);
            if (getContext() != null) {
                new AlertDialog.Builder(getContext())
                    .setTitle("Error")
                    .setMessage("Failed to initialize statistics: " + e.getMessage())
                    .setPositiveButton("OK", null)
                    .show();
            }
        }

        Log.d(TAG, "onCreateView: Completed initialization");
        return view;
    }

    private void updateStatistics(List<Transaction> transactions) {
        Log.d(TAG, "updateStatistics: Starting update");
        try {
            if (transactions == null) {
                transactions = new ArrayList<>();
            }
            
            Log.d(TAG, "updateStatistics: Updating summary cards");
            updateSummaryCards(transactions);
            
            Log.d(TAG, "updateStatistics: Updating pie chart");
            updatePieChart(transactions);
            
            Log.d(TAG, "updateStatistics: Updating bar chart");
            updateBarChart(transactions);
            
            Log.d(TAG, "updateStatistics: Updating trend analysis");
            updateTrendAnalysis(transactions);
            
            Log.d(TAG, "updateStatistics: Update completed");
        } catch (Exception e) {
            Log.e(TAG, "Error in updateStatistics", e);
        }
    }

    private void updateSummaryCards(List<Transaction> transactions) {
        double totalIncome = 0;
        double totalExpenses = 0;
        double lastMonthIncome = 0;
        double lastMonthExpenses = 0;
        
        Calendar calendar = Calendar.getInstance();
        int currentMonth = calendar.get(Calendar.MONTH);
        int currentYear = calendar.get(Calendar.YEAR);
        
        calendar.add(Calendar.MONTH, -1);
        int lastMonth = calendar.get(Calendar.MONTH);
        int lastYear = calendar.get(Calendar.YEAR);

        for (Transaction transaction : transactions) {
            Calendar transactionDate = Calendar.getInstance();
            transactionDate.setTimeInMillis(transaction.getDate());
            int transMonth = transactionDate.get(Calendar.MONTH);
            int transYear = transactionDate.get(Calendar.YEAR);

            if (transMonth == currentMonth && transYear == currentYear) {
                if (transaction.isExpense()) {
                    totalExpenses += transaction.getAmount();
                } else {
                    totalIncome += transaction.getAmount();
                }
            } else if (transMonth == lastMonth && transYear == lastYear) {
                if (transaction.isExpense()) {
                    lastMonthExpenses += transaction.getAmount();
                } else {
                    lastMonthIncome += transaction.getAmount();
                }
            }
        }

        // Update net balance
        double balance = totalIncome - totalExpenses;
        netBalance.setText(String.format(Locale.getDefault(), "$%.2f", balance));
        netBalance.setTextColor(balance >= 0 ? Color.WHITE : Color.RED);

        // Update income with change percentage
        monthlyIncome.setText(String.format(Locale.getDefault(), "$%.2f", totalIncome));
        if (lastMonthIncome > 0) {
            double incomeChangePercent = ((totalIncome - lastMonthIncome) / lastMonthIncome) * 100;
            String changeText = String.format(Locale.getDefault(), "%.1f%% %s last month",
                Math.abs(incomeChangePercent),
                incomeChangePercent >= 0 ? "↑ from" : "↓ from");
            incomeChange.setText(changeText);
            incomeChange.setTextColor(incomeChangePercent >= 0 ? Color.parseColor("#43A047") : Color.parseColor("#E53935"));
        }

        // Update expenses with change percentage
        monthlySpending.setText(String.format(Locale.getDefault(), "$%.2f", totalExpenses));
        if (lastMonthExpenses > 0) {
            double expenseChangePercent = ((totalExpenses - lastMonthExpenses) / lastMonthExpenses) * 100;
            String changeText = String.format(Locale.getDefault(), "%.1f%% %s last month",
                Math.abs(expenseChangePercent),
                expenseChangePercent >= 0 ? "↑ from" : "↓ from");
            spendingChange.setText(changeText);
            spendingChange.setTextColor(expenseChangePercent <= 0 ? Color.parseColor("#43A047") : Color.parseColor("#E53935"));
        }
    }

    private void updateTrendAnalysis(List<Transaction> transactions) {
        // Calculate month-over-month change
        Map<String, Double> monthlyTotals = new HashMap<>();
        Calendar calendar = Calendar.getInstance();
        
        for (Transaction transaction : transactions) {
            if (transaction.isExpense()) {
                Calendar transactionDate = Calendar.getInstance();
                transactionDate.setTimeInMillis(transaction.getDate());
                String monthYear = monthFormat.format(transactionDate.getTime());
                
                double currentTotal = monthlyTotals.getOrDefault(monthYear, 0.0);
                monthlyTotals.put(monthYear, currentTotal + transaction.getAmount());
            }
        }

        // Generate trend analysis text
        List<String> months = new ArrayList<>(monthlyTotals.keySet());
        if (months.size() >= 2) {
            double currentMonth = monthlyTotals.get(months.get(months.size() - 1));
            double previousMonth = monthlyTotals.get(months.get(months.size() - 2));
            double percentageChange = ((currentMonth - previousMonth) / previousMonth) * 100;

            String trend = percentageChange > 0 ? "increased" : "decreased";
            trendAnalysis.setText(String.format(
                "Your spending has %s by %.1f%% compared to last month.",
                trend, Math.abs(percentageChange)
            ));
        } else {
            trendAnalysis.setText("Not enough data to analyze spending trends.");
        }
    }

    private void setupPieChart() {
        Log.d(TAG, "setupPieChart: Starting setup");
        try {
            if (pieChart != null) {
                pieChart.setDescription(null);
                pieChart.setHoleRadius(35f);
                pieChart.setTransparentCircleRadius(40f);
                pieChart.setDrawHoleEnabled(true);
                pieChart.setRotationEnabled(true);
                pieChart.setHighlightPerTapEnabled(true);
                pieChart.setEntryLabelTextSize(12f);
                pieChart.setEntryLabelColor(Color.BLACK);
                pieChart.getLegend().setEnabled(false);
                Log.d(TAG, "setupPieChart: Setup completed");
            } else {
                Log.e(TAG, "setupPieChart: PieChart is null");
            }
        } catch (Exception e) {
            Log.e(TAG, "Error in setupPieChart", e);
        }
    }

    private void setupBarChart() {
        if (barChart != null) {
            barChart.setDescription(null);
            barChart.setDrawGridBackground(false);
            barChart.setDrawBarShadow(false);
            barChart.setHighlightFullBarEnabled(false);

            XAxis xAxis = barChart.getXAxis();
            xAxis.setPosition(XAxis.XAxisPosition.BOTTOM);
            xAxis.setGranularity(1f);
            xAxis.setDrawGridLines(false);

            barChart.getAxisLeft().setDrawGridLines(false);
            barChart.getAxisRight().setEnabled(false);
            barChart.getLegend().setEnabled(false);
        }
    }

    private void updatePieChart(List<Transaction> transactions) {
        Map<String, Float> categoryTotals = new HashMap<>();
        float totalSpending = 0f;
        
        // Calculate totals by category
        for (Transaction transaction : transactions) {
            if (transaction.isExpense()) {
                String category = transaction.getCategory();
                float currentTotal = categoryTotals.getOrDefault(category, 0f);
                float amount = (float) transaction.getAmount();
                categoryTotals.put(category, currentTotal + amount);
                totalSpending += amount;
            }
        }

        // Create pie chart entries and breakdown items
        List<PieEntry> entries = new ArrayList<>();
        List<CategoryBreakdownAdapter.CategoryBreakdown> breakdownItems = new ArrayList<>();
        
        for (Map.Entry<String, Float> entry : categoryTotals.entrySet()) {
            entries.add(new PieEntry(entry.getValue(), entry.getKey()));
            double percentage = (entry.getValue() / totalSpending) * 100;
            breakdownItems.add(new CategoryBreakdownAdapter.CategoryBreakdown(
                entry.getKey(),
                entry.getValue(),
                percentage
            ));
        }

        // Update pie chart
        PieDataSet dataSet = new PieDataSet(entries, "Categories");
        dataSet.setColors(ColorTemplate.MATERIAL_COLORS);
        dataSet.setValueTextSize(12f);
        dataSet.setValueTextColor(Color.BLACK);

        PieData data = new PieData(dataSet);
        pieChart.setData(data);
        pieChart.invalidate();

        // Update breakdown list
        if (categoryBreakdownList.getAdapter() instanceof CategoryBreakdownAdapter) {
            CategoryBreakdownAdapter adapter = (CategoryBreakdownAdapter) categoryBreakdownList.getAdapter();
            adapter.setData(breakdownItems);
        }
    }

    private void updateBarChart(List<Transaction> transactions) {
        // Get spending for last 6 months
        Map<String, Float> monthlyTotals = new HashMap<>();
        List<String> months = new ArrayList<>();
        Calendar calendar = Calendar.getInstance();
        
        // Initialize last 6 months
        for (int i = 5; i >= 0; i--) {
            calendar.add(Calendar.MONTH, -i);
            String monthYear = String.format("%d/%d", 
                calendar.get(Calendar.MONTH) + 1,
                calendar.get(Calendar.YEAR));
            months.add(monthYear);
            monthlyTotals.put(monthYear, 0f);
            calendar = Calendar.getInstance(); // Reset calendar
        }

        // Calculate monthly totals
        for (Transaction transaction : transactions) {
            if (transaction.isExpense()) {
                Calendar transactionDate = Calendar.getInstance();
                transactionDate.setTimeInMillis(transaction.getDate());
                String monthYear = String.format("%d/%d",
                    transactionDate.get(Calendar.MONTH) + 1,
                    transactionDate.get(Calendar.YEAR));
                
                if (monthlyTotals.containsKey(monthYear)) {
                    float currentTotal = monthlyTotals.get(monthYear);
                    monthlyTotals.put(monthYear, currentTotal + (float) transaction.getAmount());
                }
            }
        }

        // Create bar entries
        List<BarEntry> entries = new ArrayList<>();
        for (int i = 0; i < months.size(); i++) {
            entries.add(new BarEntry(i, monthlyTotals.get(months.get(i))));
        }

        BarDataSet dataSet = new BarDataSet(entries, "Monthly Spending");
        dataSet.setColors(ColorTemplate.MATERIAL_COLORS[0]);

        BarData data = new BarData(dataSet);
        data.setBarWidth(0.6f);
        
        // Set month labels
        barChart.getXAxis().setValueFormatter(new IndexAxisValueFormatter(months));
        barChart.setData(data);
        barChart.invalidate();
    }

    private void setupCategoryBreakdownList() {
        if (categoryBreakdownList != null && getContext() != null) {
            categoryBreakdownList.setLayoutManager(new LinearLayoutManager(getContext()));
            categoryBreakdownList.setAdapter(new CategoryBreakdownAdapter());
        }
    }

    private void checkPermissionAndExportPdf() {
        exportPdf();
    }

    private void exportPdf() {
        try {
            String fileName = "Financial_Report_" + 
                new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault())
                    .format(new Date()) + ".pdf";

            Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
            intent.addCategory(Intent.CATEGORY_OPENABLE);
            intent.setType("application/pdf");
            intent.putExtra(Intent.EXTRA_TITLE, fileName);

            startActivityForResult(intent, CREATE_FILE_REQUEST_CODE);
        } catch (Exception e) {
            Log.e(TAG, "Failed to initiate PDF export", e);
            showError("Failed to initiate PDF export: " + e.getMessage());
        }
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == CREATE_FILE_REQUEST_CODE && resultCode == RESULT_OK) {
            if (data != null && data.getData() != null) {
                Uri uri = data.getData();
                writePdfContent(uri);
            }
        }
    }

    private void writePdfContent(Uri uri) {
        try {
            ContentResolver contentResolver = requireContext().getContentResolver();
            try (OutputStream outputStream = contentResolver.openOutputStream(uri)) {
                if (outputStream != null) {
                    PdfWriter writer = new PdfWriter(outputStream);
                    PdfDocument pdf = new PdfDocument(writer);
                    Document document = new Document(pdf);

                    try {
                        createPdfContent(document);
                    } finally {
                        document.close();
                    }

                    showSuccess("Report saved successfully");
                }
            }
        } catch (Exception e) {
            Log.e(TAG, "Failed to write PDF content", e);
            showError("Failed to save PDF: " + e.getMessage());
        }
    }

    private void showSuccess(String message) {
        if (getContext() != null) {
            new AlertDialog.Builder(getContext())
                .setTitle("Success")
                .setMessage(message)
                .setPositiveButton("OK", null)
                .show();
        }
    }

    private void showError(String message) {
        if (getContext() != null) {
            new AlertDialog.Builder(getContext())
                .setTitle("Error")
                .setMessage(message)
                .setPositiveButton("OK", null)
                .show();
        }
    }

    private void createPdfContent(Document document) {
        // Add title
        Paragraph title = new Paragraph("Financial Report")
                .setFontSize(24);
        document.add(title);

        // Add date
        document.add(new Paragraph("Generated on: " + 
            new SimpleDateFormat("MMMM dd, yyyy", Locale.getDefault())
                .format(new Date())));

        // Add monthly summary
        document.add(new Paragraph("\nMonthly Summary")
                .setFontSize(18));
        document.add(new Paragraph("Monthly Spending: " + monthlySpending.getText()));

        // Add category breakdown
        document.add(new Paragraph("\nCategory Breakdown")
                .setFontSize(18));

        Table table = new Table(3);
        table.addCell("Category");
        table.addCell("Amount");
        table.addCell("Percentage");

        if (categoryBreakdownList.getAdapter() instanceof CategoryBreakdownAdapter) {
            CategoryBreakdownAdapter adapter = (CategoryBreakdownAdapter) categoryBreakdownList.getAdapter();
            for (CategoryBreakdownAdapter.CategoryBreakdown item : adapter.getItems()) {
                table.addCell(item.category);
                table.addCell(String.format(Locale.getDefault(), "$%.2f", item.amount));
                table.addCell(String.format(Locale.getDefault(), "%.1f%%", item.percentage));
            }
        }
        document.add(table);

        // Add trend analysis
        document.add(new Paragraph("\nTrend Analysis")
                .setFontSize(18));
        document.add(new Paragraph(trendAnalysis.getText().toString()));
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        if (requestCode == PERMISSION_REQUEST_CODE) {
            boolean allPermissionsGranted = true;
            for (int result : grantResults) {
                if (result != PackageManager.PERMISSION_GRANTED) {
                    allPermissionsGranted = false;
                    break;
                }
            }
            
            if (allPermissionsGranted) {
                exportPdf();
            } else {
                new AlertDialog.Builder(requireContext())
                        .setTitle("Permission Required")
                        .setMessage("Storage permissions are required to save the PDF report.")
                        .setPositiveButton("Settings", (dialog, which) -> {
                            // Open app settings
                            Intent intent = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
                            Uri uri = Uri.fromParts("package", requireActivity().getPackageName(), null);
                            intent.setData(uri);
                            startActivity(intent);
                        })
                        .setNegativeButton("Cancel", null)
                        .show();
            }
        }
    }
} 