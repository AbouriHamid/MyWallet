package com.example.portefeullle;

import android.app.AlertDialog;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.example.portefeullle.adapters.CategoryAdapter;
import com.example.portefeullle.data.AppDatabase;
import com.example.portefeullle.data.Category;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class CategoriesFragment extends Fragment {
    private RecyclerView recyclerView;
    private FloatingActionButton fabAddCategory;
    private CategoryAdapter adapter;
    private AppDatabase database;
    private ExecutorService executorService;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_categories, container, false);
        
        database = AppDatabase.getInstance(requireContext());
        executorService = Executors.newSingleThreadExecutor();
        
        recyclerView = view.findViewById(R.id.categories_recycler_view);
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
        
        adapter = new CategoryAdapter();
        recyclerView.setAdapter(adapter);
        
        fabAddCategory = view.findViewById(R.id.fab_add_category);
        fabAddCategory.setOnClickListener(v -> showAddCategoryDialog());
        
        // Observe categories
        database.categoryDao().getAllCategories().observe(getViewLifecycleOwner(), categories -> {
            adapter.setCategories(categories);
        });
        
        return view;
    }

    private void showAddCategoryDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(getContext());
        LayoutInflater inflater = requireActivity().getLayoutInflater();
        View dialogView = inflater.inflate(R.layout.dialog_add_category, null);
        
        EditText nameEdit = dialogView.findViewById(R.id.edit_category_name);
        EditText budgetEdit = dialogView.findViewById(R.id.edit_budget);
        EditText descriptionEdit = dialogView.findViewById(R.id.edit_category_description);

        builder.setView(dialogView)
               .setTitle("Add Category")
               .setPositiveButton("Add", (dialog, which) -> {
                   String name = nameEdit.getText().toString();
                   String budgetStr = budgetEdit.getText().toString();
                   String description = descriptionEdit.getText().toString();

                   if (!name.isEmpty() && !budgetStr.isEmpty()) {
                       double budget = Double.parseDouble(budgetStr);
                       Category category = new Category(name, budget, description);
                       saveCategory(category);
                   }
               })
               .setNegativeButton("Cancel", (dialog, which) -> dialog.cancel());

        builder.create().show();
    }

    private void saveCategory(Category category) {
        executorService.execute(() -> {
            database.categoryDao().insert(category);
        });
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        executorService.shutdown();
    }
} 