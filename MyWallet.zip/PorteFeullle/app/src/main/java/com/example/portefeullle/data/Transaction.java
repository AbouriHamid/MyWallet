package com.example.portefeullle.data;

import androidx.room.Entity;
import androidx.room.PrimaryKey;
import java.util.Date;

@Entity(tableName = "transactions")
public class Transaction {
    @PrimaryKey(autoGenerate = true)
    private int id;
    private double amount;
    private String description;
    private String category;
    private boolean isExpense;
    private long date;

    public Transaction() {
        // Required by Room
    }

    public Transaction(double amount, String description, String category, boolean isExpense) {
        this.amount = amount;
        this.description = description;
        this.category = category;
        this.isExpense = isExpense;
        this.date = new Date().getTime();
    }

    // Getters and Setters
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    public double getAmount() { return amount; }
    public void setAmount(double amount) { this.amount = amount; }
    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }
    public String getCategory() { return category; }
    public void setCategory(String category) { this.category = category; }
    public boolean isExpense() { return isExpense; }
    public void setExpense(boolean expense) { isExpense = expense; }
    public long getDate() { return date; }
    public void setDate(long date) { this.date = date; }
} 