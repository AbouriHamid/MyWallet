package com.example.portefeullle.adapters;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.example.portefeullle.R;
import java.util.ArrayList;
import java.util.List;

public class CategoryBreakdownAdapter extends RecyclerView.Adapter<CategoryBreakdownAdapter.ViewHolder> {
    private List<CategoryBreakdown> items = new ArrayList<>();

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_category_breakdown, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        CategoryBreakdown item = items.get(position);
        holder.categoryName.setText(item.category);
        holder.amount.setText(String.format("$%.2f", item.amount));
        holder.percentage.setText(String.format("%.1f%%", item.percentage));
    }

    @Override
    public int getItemCount() {
        return items.size();
    }

    public void setData(List<CategoryBreakdown> newItems) {
        items = newItems;
        notifyDataSetChanged();
    }

    public List<CategoryBreakdown> getItems() {
        return new ArrayList<>(items);
    }

    static class ViewHolder extends RecyclerView.ViewHolder {
        TextView categoryName;
        TextView amount;
        TextView percentage;

        ViewHolder(View itemView) {
            super(itemView);
            categoryName = itemView.findViewById(R.id.category_name);
            amount = itemView.findViewById(R.id.amount);
            percentage = itemView.findViewById(R.id.percentage);
        }
    }

    public static class CategoryBreakdown {
        public String category;
        public double amount;
        public double percentage;

        public CategoryBreakdown(String category, double amount, double percentage) {
            this.category = category;
            this.amount = amount;
            this.percentage = percentage;
        }
    }
} 